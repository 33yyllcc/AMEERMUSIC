local function contentuser(msg)
if msg.content.text then
text = msg.content.text.text
else 
text = nil
end
------------------------------------------------------------
function InfoUser(id)
local get = io.popen('curl -s "https://black-source.xyz/Api/InfoUser.php?id='..id..'"'):read('*a')
return get
end
------------------------------------------------------------
if text == 'انشاء حسابي' then
bot.sendText(msg.chat_id,msg.id,InfoUser(msg.sender_id.user_id))  
end
------------------------------------------------------------
end -- contentuser(msg)
return {Run = contentuser}
