local function Rdodbot(msg)
if msg.content.text then
text = msg.content.text.text
else 
text = nil
end
------------------------------------------------------------
------------------------------------------------------------
if text == 'تفعيل ردود البوت' and Creator(msg) then         
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
Text = Reply_Status(msg.sender_id.user_id,"*℘︙تم "..text.." بنجاح*").by
redis:del(bot_id..":"..msg.chat_id..":Rdodbot")  
else
Text = Reply_Status(msg.sender_id.user_id,"*℘︙تم "..text.." سابقا*").yu
end
bot.sendText(msg.chat_id,msg.id,Text,"md",true)
end
if text == 'تعطيل ردود البوت' and Creator(msg) then        
if not redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
redis:set(bot_id..":"..msg.chat_id..":Rdodbot",true)  
Text = Reply_Status(msg.sender_id.user_id,"*℘︙تم "..text.." بنجاح*").by
else
Text = Reply_Status(msg.sender_id.user_id,"*℘︙تم "..text.." سابقا*").yu
end
bot.sendText(msg.chat_id,msg.id,Text,"md",true)
end
--
------------------------------
if text == "هلو" or text == "هلاو" or text == "هاي" or text == "هولا" or text == "هايي" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"هلا بيك ","نورت يحلو ","امشي ولي ","نورتتتت مسيو كلشش"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "شلونكم" or text == "شلونك" or text == "شلونج" or text == "شونك" or text == "شونج" or text == "شونكم" or text == "شلخبار" or text == "شخباركم" or text == "شخبارك" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"تمام عمري انت شلونك؟ ","لعبانه نفسي من الدنيا"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end

if text == "تمام" or text == "زين" or text == "الحمد لله" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"تـدوم عمࢪيي💘","عسا دومم","عساك بالموت ","محه"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "😐" or text == "وت" or text == "وات" or text == "شنو" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"شبي الحلو صافن؟ ","شبيك ثول","لاتصفن الدنيا متسوا"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "اريد اكبل" or text == "اريد ارتبط" or text == "اردرتبط" or text == "اردكبل" or text == "خلحبك" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"امـشي وخࢪ مـنـا يدوࢪ تـڪـبيل😏","وخـࢪ مـنـا مـاࢪيـد زواحـف😹","ادعـبل ابـنـي😚","اࢪتـبـط مـحـد لازمـك🙊","خـل اࢪتـبـط انـي بالاول😹"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "ريد ازحف" or text == "ازحفلج" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"شـعليڪ بـي عمࢪيي خـلي يـزحف💘☹️","عـيـب ابـنـي😐😹","شـگـبـࢪگ شـعـرضـك تـزحـف😹😕","بـعـدگ زغـيـࢪ ع زحـف ابـنـي😹😒"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "كلخرا" or text == "اكليخرا" or text == "اكل خرا" or text == "كلزق" or text == "اكل زق " or text == "كل زق" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"اسف ماخليك بحلكي","خلي روحك بماعون وتع","اوك اكلتك"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "دي" or text == "دد" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"امـشـيڪ بـيها عمࢪيي"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "فروخ" or text == "فرخ" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"وينه بالله خلحصره","وينه خلتفل عليه"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "تعي خاص" or text == "خ" or text == "خاص" or text == "تعال خاص" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"اجي وياكم؟ ","عادي اجي؟ ","خلجي بليز اشوف "}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "اكرهج" or text == "اكرهك" or text == "ماحبك" or text == "ماحبج" or text == "ما احبك"then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"ميت عليك اني؟ ","دولي","دي"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "احبك" or text == "احبج" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"امشي ولي ماحبك","عيب تف ","خلفكر بالموضوع","اسف مرتبط","انيهم احبك كومات"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "باي" or text == "بايي" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"ويـن رايـح عمࢪيي خـلـينـا مـونـسـيـن","الله وياك حبيبي","سد الباب وراك"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "عوائل" or text == "صايره عوائل" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"عمࢪيي الـحلـو انـي ويـاڪ نـسـولف🥺😻","حـبيـبي ولله ࢪبـط فـيـشه ويـانـا🙈💋"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "واكف" or text == "بوت واكف" or text == "وكف البوت" or text == "وكف" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"شـغال عمࢪيي"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "ون مدير" or text == "وين مدير" or text == "وين المدير" or text == "ون المدير"then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"عمࢪيي تـفـضل وياڪ مـديـࢪ"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "نجب" or text == "انجب" or text == "انجبي" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"ليش شسويت","انت نجب"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "تحبيني" or text == "تحبني" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"سـؤال صـعـب خلـيـني افڪࢪ"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "صباحو" or text == "صباح الخير" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"يـمـه فـديـت صباحڪ ","اذا مو احلا صباح وياك"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "كفو" or text == "كفوو" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"ڪـفـو مـنڪ عمࢪيي"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "مساء الخير" or text == "مسائو" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"مـساء العـافـيه عمࢪيي","مساء الخرا"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "رايح للمدرسه" or text == "مدرسه" or text == "المدرسه" or text == "داروح للمدرسه" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"لاجـيـب اسـمـها لاسـطࢪڪ"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "هههه" or text == "ههههه" or text == "ههه" or text == "هه" or text == "😂" or text == "😂😂" or text == "😂😂😂" or text == "😂😂😂😂"then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"ايع شهالضحكه","عسا دوم الضحكه"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "احبجج" or text == "حبجج" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"جـذاب تࢪا يـضـحڪ علـيـج😼"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "خرب الله" or text == "خربالله" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"هسه رجال انته من كفرت؟ ","شتحس؟"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "عبود" or text == "زيد" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"هذا المبرمج مالتي حبيبي","شتريد من مبرمج؟ "}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "ضايج" or text == "ضوجه" or text == "ملل" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"@ocoooy","ادخل شوف @ocoooy"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "؟" or text == "؟؟ " or text == "؟؟؟ " or text == "؟؟؟ "then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"عود هوه عصبي وكذا ","مسوي عصبي "}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "." or text == ".." then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"يا الله","اللهم صل على محمد وعلى آل محمد"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "السلام عليكم" or text == "سلام" or text == "سلامعليكم" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"وعليكم السلام ورحمه الله وبركاته","وعليكم السلام"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "ليش" or text == "واي" or text == "ليشش" or text == "ليش؟ " or text == "ليشش؟"then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"بكيفي","يعجبنييي"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "+" or text == "++" or text == "+++" or text == "اتفق"then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"اطلق من يتفق","مو صح؟ "}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "مسيو" or text == "مشتاق" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"انيهم مسيو","مور عمري "}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "سيو" or text == "جاو" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"الله وياك ","سيو تو"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "زق" or text == "بوت زق" or text == "بوت زربه" or text == "بوت زربا" or text == "بوت زباله"then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"انت الزربه","ليش تفشر عليه؟ "}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "كانسر" or text == "كرنج" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"ماكو غيرك كانسر","انت الكرنج"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "تع اتصال" or text == "اصعد" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"اصبرو صبرو خلجي","عادي اجي وياكم؟ "}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "اكلك" or text == "اكول" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"كول عمري","تفضل"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
if text == "لتكفرنه" or text == "لتكفرنه بالله" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"كول يا الله","صلى عالنبي"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
  if text == "ماريد" or text == "ما اريد" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"لا بربك ريد","انيهم والله"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
   if text == "بالبيت" or text == "بالمحل" or text == "بالمدرسه" or text == "بالشغل" or text == "بخشمك" or text == "بطيزك" or text == "بالشركه" or text == "طالع" or text == "بالدرس" or text == "بالمحاضره"  then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"اجي يمك؟","لعد وين قابل بخشمي"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
      if text == "هف" or text == "هفف" or text == "هففف" or text == "هفففف" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"لاتضوج","هانت عمري هانت"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
       if text == "والله" or text == "والله العضيم" or text == "والعباس" or text == "والحسين" or text == "والكاظم" or text == "والزهره" or text == "والنبي" or text == "ونبي" or text == "وداعه امي" or text == "وروح امي"  then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"ايي وبعدين شصار؟؟","ميحتاج تحلف صدكت"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
     if text == "مت" or text == "متت" or text == "متتت" or text == "متتتت" or text == "متتتتت" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"لا الله عليك لاتموت","امك فرحت بيك من جابتك؟"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
      if text == "بغداد" or text == "البصره" or text == "كربلاء" or text == "كركوك" or text == "الناصريه" or text == "الموصل" or text == "تكريت" or text == "ديالى" or text == "دهوك" or text == "اربيل" or text == "العماره" or text == "واسط" or text == "نينوى" or text == "النجف" or text == "الدوره" or text == "المنصور" or text == "السيديه" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"اني من @MEGGAX","عالراس والله"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
     if text == "طيني" or text == "انطيني" or text == "جيب" or text == "دزه" or text == "طينيا" or text == "انطينيا" then
if redis:get(bot_id..":"..msg.chat_id..":Rdodbot") then
return bot.sendText(msg.chat_id,msg.id,"md",true)  
end
nameBot = {"فكر","شكد فكر خربيومك"}
bot.sendText(msg.chat_id,msg.id,"*"..nameBot[math.random(#nameBot)].."*","md",true)  
end
    
------------------------------------------------------------
end -- Rdodbot(msg)
return {Run = Rdodbot}
