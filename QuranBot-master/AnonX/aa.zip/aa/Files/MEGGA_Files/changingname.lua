local function ChengName(msg)
if msg.content.text then
text = msg.content.text.text
else 
text = nil
end
------------------------------------------------------------
if BasicConstructor(msg) then
if text == "تفعيل تنبيه الاسماء" then
if not redis:get(bot_id..'lock_chengname'..msg.chat_id) then 
return bot.sendText(msg.chat_id,msg.id,"- تم تفعيل التنبيه سابقا .","md",true)  
else 
redis:del(bot_id..'lock_chengname'..msg.chat_id) 
return bot.sendText(msg.chat_id,msg.id,"- تم تفعيل التنبيه .","md",true)  
end 
end
if text == "تعطيل تنبيه الاسماء" then
if redis:get(bot_id..'lock_chengname'..msg.chat_id) then 
return bot.sendText(msg.chat_id,msg.id,"- تم تعطيل التنبيه سابقا .","md",true)  
else
redis:set(bot_id..'lock_chengname'..msg.chat_id,true)  
return bot.sendText(msg.chat_id,msg.id,"- تم تعطيل التنبيه .","md",true)  
end   
end
end
------------------------------
if text and not redis:get(bot_id..'lock_chengname'..msg.chat_id) then   
local UserInfo = bot.getUser(msg.sender_id.user_id)
if redis:get(bot_id.."chencher"..msg.sender_id.user_id) then 
if redis:get(bot_id.."chencher"..msg.sender_id.user_id) ~= UserInfo.first_name then 
nam = '['..(redis:get(bot_id.."chencher"..msg.sender_id.user_id) or '')..']'
namw = '['..UserInfo.first_name..']'
local rt ={ 
'\n ليش غيرت اسمك  يا حلو 😹',
'\n شهل اسم الفيطي '..namw.. ' \n رجعه ؏ قديم \n '..nam..'',
'\nليش غيرت اسمك  '..nam..' ',
}
bot.sendText(msg.chat_id,msg.id,rt[math.random(#rt)],"md",true)  
end  
end
redis:set(bot_id.."chencher"..msg.sender_id.user_id, UserInfo.first_name) 
end
------------------------------------------------------------
end -- ChengName(msg)
return {Run = ChengName}
