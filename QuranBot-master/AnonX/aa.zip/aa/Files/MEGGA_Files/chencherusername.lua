local function ChengUserName(msg)
if msg.content.text then
text = msg.content.text.text
else 
text = nil
end
------------------------------------------------------------
if BasicConstructor(msg) then
if text == "تفعيل تنبيه المعرفات" then
if not redis:get(bot_id..'lock_chengusername'..msg.chat_id) then 
return bot.sendText(msg.chat_id,msg.id,"- تم تفعيل التنبيه سابقا .","md",true)  
else 
redis:del(bot_id..'lock_chengusername'..msg.chat_id) 
return bot.sendText(msg.chat_id,msg.id,"- تم تفعيل التنبيه .","md",true)  
end 
end
if text == "تعطيل تنبيه المعرفات" then
if redis:get(bot_id..'lock_chengusername'..msg.chat_id) then 
return bot.sendText(msg.chat_id,msg.id,"- تم تعطيل التنبيه سابقا .","md",true)  
else
redis:set(bot_id..'lock_chengusername'..msg.chat_id,true)  
return bot.sendText(msg.chat_id,msg.id,"- تم تعطيل التنبيه .","md",true)  
end   
end
end
------------------------------
if not redis:get(bot_id..'lock_chengusername'..msg.chat_id) then   
local UserInfo = bot.getUser(msg.sender_id.user_id)
if UserInfo.username and UserInfo.username == "" then
if redis:get(bot_id.."chencherusername"..msg.sender_id.user_id) then
bot.sendText(msg.chat_id,msg.id,"حذف معرفه لمعرف لقديم : "..redis:get(bot_id.."chencherusername"..msg.sender_id.user_id)) 
redis:del(bot_id.."chencherusername"..msg.sender_id.user_id)
return false  
end
end
if UserInfo.username and UserInfo.username ~= "" then
if redis:get(bot_id.."chencherusername"..msg.sender_id.user_id) then
if redis:get(bot_id.."chencherusername"..msg.sender_id.user_id) ~= "@"..UserInfo.username then
bot.sendText(msg.chat_id,msg.id,"غير معرفه لمعرف لقديم : "..redis:get(bot_id.."chencherusername"..msg.sender_id.user_id)) 
redis:set(bot_id.."chencherusername"..msg.sender_id.user_id,"@"..UserInfo.username) 
return false  
end
end
end
end
------------------------------------------------------------
end -- chencherusername(msg)
return {Run = ChengUserName}
