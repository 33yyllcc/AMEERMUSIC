local function ChangePhoto(msg)
if msg.content.text then
text = msg.content.text.text
else 
text = nil
end
------------------------------------------------------------
if BasicConstructor(msg) then
if text == "تفعيل تنبيه الصور" then
if not redis:get(bot_id..'lock_chengPhoto'..msg.chat_id) then 
return bot.sendText(msg.chat_id,msg.id,"- تم تفعيل التنبيه سابقا .","md",true)  
else 
redis:del(bot_id..'lock_chengPhoto'..msg.chat_id) 
return bot.sendText(msg.chat_id,msg.id,"- تم تفعيل التنبيه .","md",true)  
end 
end
if text == "تعطيل تنبيه الصور" then
if redis:get(bot_id..'lock_chengPhoto'..msg.chat_id) then 
return bot.sendText(msg.chat_id,msg.id,"- تم تعطيل التنبيه سابقا .","md",true)  
else
redis:set(bot_id..'lock_chengPhoto'..msg.chat_id,true)  
return bot.sendText(msg.chat_id,msg.id,"- تم تعطيل التنبيه .","md",true)  
end   
end
end
------------------------------
if not redis:get(bot_id..'lock_chengPhoto'..msg.chat_id) then   
local photo = bot.getUserProfilePhotos(msg.sender_id.user_id)
if tonumber(photo.total_count) == tonumber(0) then  
if redis:get(bot_id.."NewchengPhoto"..msg.sender_id.user_id) then
bot.sendText(msg.chat_id,msg.id,"- ها كلب حذفت صورتك") 
redis:del(bot_id.."NewchengPhoto"..msg.sender_id.user_id)
return false  
end
end
if tonumber(photo.total_count) ~= tonumber(0) and photo.photos[1].sizes[1].photo.remote.unique_id then   
if redis:get(bot_id.."NewchengPhoto"..msg.sender_id.user_id) then
if redis:get(bot_id.."NewchengPhoto"..msg.sender_id.user_id) ~= photo.photos[1].sizes[1].photo.remote.unique_id then
local sgstxt = {
"وفف مو صوره غنبلةة، 🤤♥️",
"طالع صاكك بالصوره الجديده ممكن نرتبط؟ ، 🤤♥️",
"حطيت صوره جديده عود شوفوني اني صاكك بنات، 😹♥️",
"اححح شنيي هالصوره الجديده، 🤤♥️",
}
sgs = math.random(#sgstxt)
bot.sendText(msg.chat_id,msg.id,sgs) 
redis:set(bot_id.."NewchengPhoto"..msg.sender.user_id,photo.photos[1].sizes[1].photo.remote.unique_id) 
return false  
end
end
end
end
------------------------------------------------------------
end -- ChangePhoto(msg)
return {Run = ChangePhoto}
